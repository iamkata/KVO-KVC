//
//  main.m
//  Interview01-KVC
//
//  Created by MJ Lee on 2018/5/3.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJPerson.h"
#import "MJObserver.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        MJObserver *observer = [[MJObserver alloc] init];
        MJPerson *person = [[MJPerson alloc] init];
        
        // 添加KVO监听
        [person addObserver:observer forKeyPath:@"age" options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld context:NULL];
        
        // 通过KVC修改age属性会触发KVO (不管这个属性或者成员变量有没有set方法都会触发KVO,因为他们是配套使用的)
//        因为它内部调用了如下方法
//        [person willChangeValueForKey:@"age"];
//        person->_age = 10;
//        [person didChangeValueForKey:@"age"];
        [person setValue:@10 forKey:@"age"];
//        2019-04-11 15:55:00.568868+0800 Interview01-KVC[16345:3639722] observeValueForKeyPath - {
//            kind = 1;
//            new = 10;
//            old = 0;
//        }
        
        // 移除KVO监听
        [person removeObserver:observer forKeyPath:@"age"];
        
        //KVC的基本使用
//        person.age = 10;
//
//        NSLog(@"%@", [person valueForKey:@"age"]);
//        NSLog(@"%@", [person valueForKeyPath:@"cat.weight"]);
//
//        NSLog(@"%d", person.age);
//
//        [person setValue:[NSNumber numberWithInt:10] forKey:@"age"];
//        [person setValue:@10 forKey:@"age"];
//        person.cat = [[MJCat alloc] init];
//        [person setValue:@10 forKeyPath:@"cat.weight"];
//        setValue:@10 forKeyPath 更强大可以使用.
//        NSLog(@"%d", person.age);
        
    }
    return 0;
}
