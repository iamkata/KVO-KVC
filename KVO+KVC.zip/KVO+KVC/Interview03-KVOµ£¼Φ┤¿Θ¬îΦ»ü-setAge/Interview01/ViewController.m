//
//  ViewController.m
//  Interview01
//
//  Created by MJ Lee on 2018/4/23.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "ViewController.h"
#import "MJPerson.h"
#import <objc/runtime.h>

@interface ViewController ()
@property (strong, nonatomic) MJPerson *person1;
@property (strong, nonatomic) MJPerson *person2;
@end

// 反编译工具 - Hopper

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.person1 = [[MJPerson alloc] init];
    self.person1.age = 1;
    
    self.person2 = [[MJPerson alloc] init];
    self.person2.age = 2;
    
    
//    NSLog(@"person1添加KVO监听之前 - %@ %@",
//          object_getClass(self.person1),
//          object_getClass(self.person2));
//    NSLog(@"person1添加KVO监听之前 - %p %p",
//          [self.person1 methodForSelector:@selector(setAge:)],
//          [self.person2 methodForSelector:@selector(setAge:)]);
    
    // 给person1对象添加KVO监听
    NSKeyValueObservingOptions options = NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld;
    [self.person1 addObserver:self forKeyPath:@"age" options:options context:@"123"];
    
//    NSLog(@"person1添加KVO监听之后 - %@ %@",
//          object_getClass(self.person1),
//          object_getClass(self.person2));
//    NSLog(@"person1添加KVO监听之后 - %p %p",
//          [self.person1 methodForSelector:@selector(setAge:)],
//          [self.person2 methodForSelector:@selector(setAge:)]);
    
////获取类对象
//NSLog(@"类对象 - %p %p",
//      object_getClass(self.person1),  // 相当于获取person1的类对象(self.person1.isa)
//      object_getClass(self.person2)); // 相当于获取erson2的类对象(self.person2.isa)
//
//
////获取元类对象
//NSLog(@"元类对象 - %p %p",
//      object_getClass(object_getClass(self.person1)), // 相当于获取person1类对象的元类对象(self.person1.isa.isa)
//      object_getClass(object_getClass(self.person2))); // 相当于获取相当于获取person1类对象的元类对象(self.person2.isa.isa)

    
    //结论:
    //1.添加KVO之前person1和person2类对象都是MJPerson,添加KVO之后person1的类对象是NSKVONotifying_MJPerson,person2的类对象还是MJPerson
    //2.添加KVO之前person1和person2的setAge:方法地址是一样的(说明调用的是同一个方法),添加KVO之后person1和person2的setAge:方法地址不一样(说明调用的不是同一个方法)
    //3.获取类对象和元类对象的地址后发现四个地址都不一样,NSKVONotifying_MJPerson类对象的isa指向他自己的元类对象,MJPerson的isa也是指向他自己的元类对象,所以四个地址都不一样
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    // NSKVONotifying_MJPerson是使用Runtime动态创建的一个类，是MJPerson的子类
    // self.person1.isa == NSKVONotifying_MJPerson
    [self.person1 setAge:21];
    
    // self.person2.isa = MJPerson
//    [self.person2 setAge:22];
}

- (void)dealloc {
    [self.person1 removeObserver:self forKeyPath:@"age"];
}

// 当监听对象的属性值发生改变时，就会调用
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context
{
    NSLog(@"监听到%@的%@属性值改变了 - %@ - %@", object, keyPath, change, context);
}

//总结:调用顺序为:
/*
 1.  willChangeValueForKey 将要改变
 2.  setAge(原来的set方法)   真的去改变
 3.  didChangeValueForKey  已经改变
 4.  observeValueForKeyPath:ofObject:change:context: 监听到MJPerson的age属性改变了
 */

@end
