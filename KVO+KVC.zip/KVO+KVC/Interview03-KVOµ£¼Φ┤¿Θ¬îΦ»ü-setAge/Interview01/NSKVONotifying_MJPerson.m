//
//  NSKVONotifying_MJPerson.m
//  Interview01
//
//  Created by MJ Lee on 2018/4/23.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "NSKVONotifying_MJPerson.h"

@implementation NSKVONotifying_MJPerson

- (void)setAge:(int)age
{
    _NSSetIntValueAndNotify();
}

// 伪代码
void _NSSetIntValueAndNotify()
{
    [self willChangeValueForKey:@"age"];
    [super setAge:age];
    [self didChangeValueForKey:@"age"];
}

- (void)didChangeValueForKey:(NSString *)key
{
    // 通知监听器，某某属性值发生了改变
    [oberser observeValueForKeyPath:key ofObject:self change:nil context:nil];
}

//总结:调用顺序为:
/*
 1.  willChangeValueForKey 将要改变
 2.  setAge(原来的set方法)   真的去改变
 3.  didChangeValueForKey  已经改变
 4.  observeValueForKeyPath:ofObject:change:context: 监听到MJPerson的age属性改变了
 */

@end
