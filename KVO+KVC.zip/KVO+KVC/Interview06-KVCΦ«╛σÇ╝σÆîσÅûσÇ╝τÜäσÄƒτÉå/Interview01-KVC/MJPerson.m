//
//  MJPerson.m
//  Interview01-KVC
//
//  Created by MJ Lee on 2018/5/3.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson.h"

@implementation MJPerson

#pragma mark - KVO的set流程

//1.setAge
//- (void)setAge:(int)age
//{
//    NSLog(@"setAge: - %d", age);
//}
//
//2._setAge
//- (void)_setAge:(int)age
//{
//    NSLog(@"_setAge: - %d", age);
//}
//
//3.找不到上面两个方法就调用accessInstanceVariablesDirectly问问能不能直接访问成员变量
// 默认的返回值就是YES
//+ (BOOL)accessInstanceVariablesDirectly
//{
//    return YES;
//}
//
//4.1 如果返回NO,就调用setValue:forUndefinedKey:并抛出异常NSUnknownKeyException
//4.2如果返回YES,会按顺序_key,_isKey,key,isKey赋值,如果四个都找不到就报上面的错

//KVC修改属性setValue:forKey 会调用下面的方法,所以说setValue:forKey会触发KVO
//- (void)willChangeValueForKey:(NSString *)key
//{
//    [super willChangeValueForKey:key];
//    NSLog(@"willChangeValueForKey - %@", key);
//}
//
//- (void)didChangeValueForKey:(NSString *)key
//{
//    NSLog(@"didChangeValueForKey - begin - %@", key);
//    [super didChangeValueForKey:key];
//    NSLog(@"didChangeValueForKey - end - %@", key);
//}

#pragma mark - KVC的get流程

//1.getAge
//- (int)getAge
//{
//    return 11;
//}

//2.age
//- (int)age
//{
//    return 12;
//}

//3.isAge
//- (int)isAge
//{
//    return 13;
//}

//4._age
//- (int)_age
//{
//    return 14;
//}

//5.3.找不到上面四个方法就调用accessInstanceVariablesDirectly问问能不能直接访问成员变量
// 默认的返回值就是YES
//+ (BOOL)accessInstanceVariablesDirectly
//{
//    return YES;
//}

//5.1 如果返回NO,就调用valueforUndefinedKey:并抛出异常NSUnknownKeyException
//5.2如果返回YES,会按顺序_key,_isKey,key,isKey赋值,如果四个都找不到就报上面的错

@end
