//
//  ViewController.m
//  Interview01
//
//  Created by MJ Lee on 2018/4/23.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "ViewController.h"
#import "MJPerson.h"
#import <objc/runtime.h>

@interface ViewController ()
@property (strong, nonatomic) MJPerson *person1;
@property (strong, nonatomic) MJPerson *person2;
@end

//如果NSKVONotifying_MJPerson没有实现class方法,最后会调用到NSObject的class方法,会直接返回NSKVONotifying_MJPerson
//NSObject 内部这样实现的
//@implementation NSObject
//
//- (Class)class
//{
//    return object_getClass(self);
//}
//
//@end

// 反编译工具 - Hopper

@implementation ViewController

//获取一个类里面所有的方法
- (void)printMethodNamesOfClass:(Class)cls
{
    unsigned int count;
    // 获得方法数组
    Method *methodList = class_copyMethodList(cls, &count);
    
    // 存储方法名
    NSMutableString *methodNames = [NSMutableString string];
    
    // 遍历所有的方法
    for (int i = 0; i < count; i++) {
        // 获得方法
        Method method = methodList[i];
        // 获得方法名
        NSString *methodName = NSStringFromSelector(method_getName(method));
        // 拼接方法名
        [methodNames appendString:methodName];
        [methodNames appendString:@", "];
    }
    
    //c语言中,如果数组是create或者copy出来的要free  OC中ARC不用管
    // 释放
    free(methodList);
    
    // 打印方法名
    NSLog(@"%@ %@", cls, methodNames);
    //打印结果:
//    NSKVONotifying_MJPerson setAge:, class, dealloc, _isKVOA,
//    MJPerson setAge:, age,
    //验证了NSKVONotifying_MJPerson里面有有setAge:, class, dealloc, _isKVOA四个方法
    //MJPerson里面有 setAge:, age两个方法
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.person1 = [[MJPerson alloc] init];
    self.person1.age = 1;
    
    self.person2 = [[MJPerson alloc] init];
    self.person2.age = 2;
    
    // 给person1对象添加KVO监听
    NSKeyValueObservingOptions options = NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld;
    [self.person1 addObserver:self forKeyPath:@"age" options:options context:@"123"];
    
    [self printMethodNamesOfClass:object_getClass(self.person1)];
    [self printMethodNamesOfClass:object_getClass(self.person2)];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    // 自动触发KVO
    // [self.person1 setAge:21];
    
    //直接修改成员变量不会触发KVO,因为没有调用setAge方法
    //self.person1->_age = 2;
    
    //如何手动触发KVO? 就算没有人修改age值,也想触发监听方法observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change
    //手动调用下面方法
    [self.person1 willChangeValueForKey:@"age"];
    //self.person1->_age = 2;
    [self.person1 didChangeValueForKey:@"age"];
    //didChangeValueForKey内部会判断willChangeValueForKey是否调用,所以两个都要调用
//2019-04-11 15:34:31.968473+0800 Interview01[16217:3596188] 监听到<MJPerson: 0x6000000180d0>的age属性值改变了 - {
//    kind = 1;
//    new = 1;
//    old = 1;
//} - 123
    
    //NSKVONotifying_MJPerson 为什么要重写class方法
    
    NSLog(@"%@ %@",object_getClass(self.person1),object_getClass(self.person2));
    NSLog(@"%@ %@",[self.person1 class],[self.person2 class]);
//    NSKVONotifying_MJPerson MJPerson
//    MJPerson MJPerson
//    按理说打印结果应该两个都是 NSKVONotifying_MJPerson MJPerson,为什么第二个都是MJPerson呢?
//    因为NSKVONotifying_MJPerson内部重写了class方法,NSKVONotifying_MJPerson是内部创建的,不想让用户看到,所以用户调用class方法要把NSKVONotifying_MJPerson转成MJPerson
//
//     NSKVONotifying_MJPerson内部实现了setKey class dealloc isKVO 方法
}

- (void)dealloc {
    [self.person1 removeObserver:self forKeyPath:@"age"];
}

// observeValueForKeyPath:ofObject:change:context:
// 当监听对象的属性值发生改变时，就会调用
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context
{
    NSLog(@"监听到%@的%@属性值改变了 - %@ - %@", object, keyPath, change, context);
}

@end
