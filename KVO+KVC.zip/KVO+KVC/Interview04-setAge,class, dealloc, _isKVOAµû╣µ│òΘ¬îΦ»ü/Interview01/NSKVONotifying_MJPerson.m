//
//  NSKVONotifying_MJPerson.m
//  Interview01
//
//  Created by MJ Lee on 2018/4/23.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "NSKVONotifying_MJPerson.h"

@implementation NSKVONotifying_MJPerson

//伪代码,苹果内部可能这样实现的
- (void)setAge:(int)age
{
    _NSSetIntValueAndNotify();
}

// 屏蔽内部实现，隐藏了NSKVONotifying_MJPerson类的存在
- (Class)class
{
    return [MJPerson class];
}

- (void)dealloc
{
    // 收尾工作
}

- (BOOL)_isKVOA
{
    return YES;
}

//NSKVONotifying_MJPerson内部实现了setKey class dealloc isKVO 方法
//为什么要实现class方法?
//NSKVONotifying_MJPerson是内部创建的,不想让用户看到,所以用户调用class方法要把NSKVONotifying_MJPerson转成MJPerson

@end
